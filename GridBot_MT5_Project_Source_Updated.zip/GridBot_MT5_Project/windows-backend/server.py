import json, threading, time, logging
from pathlib import Path
from typing import Optional
import MetaTrader5 as mt5
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
import uvicorn

BASE = Path(__file__).resolve().parent
cfg_path = BASE / "config.json"
if not cfg_path.exists():
    raise SystemExit("Copy config.example.json to config.json and set api_key first.")
CFG = json.loads(cfg_path.read_text(encoding="utf-8"))
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("gridbot")

app = FastAPI(title="GridBot MT5 Backend", version="1.0")
lock = threading.RLock()
state = {
    "connected": False, "account_login": None, "server": None,
    "account_mode": "UNKNOWN", "symbol": CFG["symbol"],
    "auto_trading": False, "last_signal": "WAIT",
    "last_error": None, "positions": 0, "basket_profit": 0.0,
    "cycle": 0, "last_price": None
}
stop_event = threading.Event()
worker: Optional[threading.Thread] = None
previous_price = None

class ConnectRequest(BaseModel):
    login: int = Field(gt=0)
    password: str = Field(min_length=1, max_length=256)
    server: str = Field(min_length=1, max_length=128)
    symbol: str = Field(default="XAUUSDm", min_length=1, max_length=32)

def auth(x_api_key: str | None):
    if not x_api_key or x_api_key != CFG["api_key"]:
        raise HTTPException(401, "Invalid API key")

def mt5_error():
    return str(mt5.last_error())

def bot_positions():
    positions = mt5.positions_get(symbol=state["symbol"])
    if positions is None:
        return []
    return [p for p in positions if int(p.magic) == int(CFG["magic"])]

def basket_pnl():
    return sum(float(p.profit) + float(p.swap) for p in bot_positions())

def close_all():
    for p in bot_positions():
        tick = mt5.symbol_info_tick(p.symbol)
        if tick is None:
            state["last_error"] = "No tick while closing position"
            continue
        is_buy = p.type == mt5.POSITION_TYPE_BUY
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": p.symbol,
            "volume": float(p.volume),
            "type": mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY,
            "position": p.ticket,
            "price": float(tick.bid if is_buy else tick.ask),
            "deviation": 30,
            "magic": int(CFG["magic"]),
            "comment": "GridBot close",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        result = mt5.order_send(request)
        if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
            state["last_error"] = f"Close failed for {p.ticket}: {result}"
            log.error(state["last_error"])

def open_trade(direction: str, lot: float):
    info = mt5.symbol_info(state["symbol"])
    tick = mt5.symbol_info_tick(state["symbol"])
    if info is None or tick is None:
        state["last_error"] = "Symbol unavailable or no tick"
        return False
    if not info.visible and not mt5.symbol_select(state["symbol"], True):
        state["last_error"] = f"Cannot select symbol: {state['symbol']}"
        return False
    # Broker volume constraints are checked; no silent lot-size adjustment.
    if lot < info.volume_min or lot > info.volume_max:
        state["last_error"] = f"Lot {lot} outside broker limits {info.volume_min}-{info.volume_max}"
        return False
    if abs(round(lot / info.volume_step) * info.volume_step - lot) > 1e-8:
        state["last_error"] = f"Lot {lot} does not match broker volume step {info.volume_step}"
        return False
    is_buy = direction == "BUY"
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": state["symbol"],
        "volume": float(lot),
        "type": mt5.ORDER_TYPE_BUY if is_buy else mt5.ORDER_TYPE_SELL,
        "price": float(tick.ask if is_buy else tick.bid),
        "deviation": 30,
        "magic": int(CFG["magic"]),
        "comment": "GridBot sample strategy",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    result = mt5.order_send(request)
    if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
        state["last_error"] = f"Order rejected: {result}"
        log.error(state["last_error"])
        return False
    state["last_error"] = None
    log.info("Opened %s %.2f %s ticket=%s", direction, lot, state["symbol"], result.order)
    return True

def trading_loop():
    global previous_price
    state["cycle"] += 1
    log.warning("GridBot cycle %s started", state["cycle"])
    while not stop_event.is_set():
        try:
            with lock:
                if not state["connected"] or not state["auto_trading"]:
                    break
                strategy = active_strategy()
                tick = mt5.symbol_info_tick(state["symbol"])
                if tick is None:
                    state["last_error"] = f"No tick: {mt5_error()}"
                    time.sleep(strategy["poll_seconds"])
                    continue
                mid = (float(tick.bid) + float(tick.ask)) / 2.0
                positions = bot_positions()
                pnl = basket_pnl()
                state.update(last_price=mid, positions=len(positions), basket_profit=round(pnl, 2))
                if positions:
                    target = strategy["target_at_last"] if len(positions) >= len(strategy["lots"]) else strategy["target_before_last"]
                    if pnl <= strategy["emergency_loss"] or pnl >= target:
                        log.warning("Basket exit triggered: P/L %.2f", pnl)
                        close_all()
                        time.sleep(strategy["restart_delay_seconds"])
                        previous_price = None
                        if state["auto_trading"]:
                            state["cycle"] += 1
                            continue
                        break
                if len(positions) < len(strategy["lots"]) and previous_price is not None:
                    if mid > previous_price:
                        signal = "BUY"
                    elif mid < previous_price:
                        signal = "SELL"
                    else:
                        signal = "WAIT"
                    state["last_signal"] = signal
                    if signal in ("BUY", "SELL"):
                        lot = strategy["lots"][len(positions)]
                        open_trade(signal, lot)
                else:
                    state["last_signal"] = "WAIT"
                previous_price = mid
            stop_event.wait(strategy["poll_seconds"])
        except Exception as exc:
            state["last_error"] = str(exc)
            log.exception("Trading loop error")
            stop_event.wait(CFG["poll_seconds"])
    log.warning("GridBot worker stopped")

@app.get("/health")
def health():
    return {"online": True, "service": "GridBot MT5 Backend"}

@app.post("/connect")
def connect(req: ConnectRequest, x_api_key: str | None = Header(default=None)):
    global previous_price
    auth(x_api_key)
    with lock:
        if state["auto_trading"]:
            raise HTTPException(409, "Turn Auto Trading OFF before changing account")
        if mt5.terminal_info() is not None:
            mt5.shutdown()
        ok = mt5.initialize(login=req.login, password=req.password, server=req.server)
        if not ok:
            state["connected"] = False
            state["last_error"] = f"MT5 initialize failed: {mt5_error()}"
            raise HTTPException(400, state["last_error"])
        account = mt5.account_info()
        if account is None:
            mt5.shutdown()
            raise HTTPException(400, f"MT5 account info unavailable: {mt5_error()}")
        state.update(
            connected=True, account_login=int(account.login),
            server=str(account.server), account_mode="REAL" if getattr(account, "trade_mode", 0) == 2 else "DEMO_OR_CONTEST",
            symbol=req.symbol, last_error=None, last_signal="WAIT"
        )
        previous_price = None
        return {"connected": True, "login": int(account.login), "server": str(account.server),
                "account_mode": state["account_mode"], "symbol": req.symbol}

@app.post("/disconnect")
def disconnect(x_api_key: str | None = Header(default=None)):
    auth(x_api_key)
    with lock:
        state["auto_trading"] = False
        stop_event.set()
        mt5.shutdown()
        state["connected"] = False
        return {"connected": False, "auto_trading": False}

@app.post("/auto")
def set_auto(payload: dict, x_api_key: str | None = Header(default=None)):
    global worker
    auth(x_api_key)
    enabled = bool(payload.get("enabled", False))
    with lock:
        if enabled:
            if not state["connected"]:
                raise HTTPException(409, "Connect MT5 account first")
            if state["account_mode"] == "REAL" and not CFG.get("allow_real_trading", False):
                raise HTTPException(403, "Real trading is disabled in backend config")
            if state["auto_trading"]:
                return {"auto_trading": True, "message": "Already running"}
            stop_event.clear()
            state["auto_trading"] = True
            worker = threading.Thread(target=trading_loop, daemon=True)
            worker.start()
        else:
            state["auto_trading"] = False
            stop_event.set()
    return {"auto_trading": state["auto_trading"]}

@app.get("/status")
def status(x_api_key: str | None = Header(default=None)):
    auth(x_api_key)
    with lock:
        if state["connected"]:
            ps = bot_positions()
            state.update(positions=len(ps), basket_profit=round(basket_pnl(), 2))
        return dict(state)

if __name__ == "__main__":
    uvicorn.run(app, host=CFG.get("host", "127.0.0.1"), port=int(CFG.get("port", 8787)))
