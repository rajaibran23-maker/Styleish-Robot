GRIDBOT MT5 PROJECT — SOURCE PACKAGE
====================================

اہم حقیقت
---------
یہ سورس پیکج Android APK کا Android Studio project اور Windows MT5 backend فراہم کرتا ہے۔
Backend کو Windows کمپیوٹر یا Windows VPS پر چلانا ہوگا جہاں:
1) MetaTrader 5 desktop terminal انسٹال ہو
2) Exness account اسی terminal میں لاگ اِن ہو
3) MT5 terminal میں Algo Trading فعال ہو
4) Python package MetaTrader5 نصب ہو

صرف Android MT5 app یا Termux سے Python MetaTrader5 execution نہیں چلتا۔
اس ZIP میں تیار شدہ APK شامل نہیں؛ Android Studio سے APK build کرنا ہوگا۔
اس پیکج کو compile/run کر کے live trading کی ضمانت نہیں دی جا رہی؛ پہلے Demo پر
connection، symbol، volume، order filling اور broker permissions verify کریں۔

فولڈر
------
android-app/   Android Studio project source
windows-backend/ Windows Python API + MT5 strategy
docs/          setup/security notes

Windows Backend Setup
---------------------
Windows پر Python 3.11 (64-bit) اور MetaTrader 5 desktop terminal انسٹال کریں۔
PowerShell میں:

  cd windows-backend
  py -3.11 -m venv .venv
  .\\.venv\\Scripts\\Activate.ps1
  pip install -r requirements.txt

config.example.json کو config.json کے نام سے copy کریں اور api_key کو مضبوط random
secret سے بدلیں۔ MT5 terminal کھولیں اور پہلے Demo account سے login کریں۔

  python server.py

Backend default طور پر 127.0.0.1:8787 پر listen کرتا ہے۔ اسے public internet پر
براہِ راست expose نہ کریں۔ Android فون سے remote connection کے لیے VPS پر VPN یا
TLS reverse proxy (مثلاً Caddy/Nginx) لگائیں، firewall میں صرف trusted/VPN access دیں،
اور اسی HTTPS URL کو APK میں درج کریں۔ سادہ HTTP پر password یا API key ہرگز نہ بھیجیں۔
Backend میں /health، /connect، /disconnect، /auto، /status، /strategy/import اور
/strategy/select endpoints شامل ہیں۔ Strategy import صرف محفوظ JSON profile قبول کرتا ہے۔

Android Studio
--------------
android-app فولڈر Android Studio میں Open کریں، Gradle sync کریں، پھر Build >
Build APK(s) منتخب کریں۔ compileSdk 35 اور Android Gradle Plugin 8.7.3 درکار ہیں۔
اس سورس میں Gradle wrapper شامل نہیں؛ Android Studio کے installed Gradle سے build کریں۔

استعمال
-------
1) Backend کو Windows پر چلائیں۔
2) Android app میں Backend URL اور API Key درج کریں۔
3) MT5 account number، password، server، symbol (مثلاً XAUUSDm) دیں۔
4) صرف Demo account سے Connect کریں۔
5) Auto Trading پہلے OFF رہے گی۔ اسے ON کرنے سے پہلے Demo terminal میں trade
   permission، symbol، minimum lot اور account mode خود verify کریں۔

Strategy (واضح حد)
------------------
- ہر 5 سیکنڈ میں tick چیک
- price اوپر ہو تو BUY، نیچے ہو تو SELL
- زیادہ سے زیادہ 4 bot positions: 0.01, 0.02, 0.04, 0.06
- 4 سے کم positions پر basket target +$1
- 4 positions پر basket target +$3
- emergency basket P/L <= -$50 پر close-all کوشش
- cycle restart delay 2 سیکنڈ

یہ ایک high-risk sample strategy ہے، منافع کی ضمانت نہیں۔ قیمت کا ہر معمولی tick
نئی پوزیشن کھول سکتا ہے۔ Spread، commission، swap، slippage، gaps، rejected
orders، terminal/network outage اور close failures کے باعث -$50 hard maximum loss
نہیں ہے۔ Basket close loop ہر 5 سیکنڈ پر چیک کرتا ہے، اس لیے loss حد سے آگے جا
سکتا ہے۔ Real account پر استعمال نہ کریں جب تک الگ سے مکمل risk controls، SL،
max daily loss، position reconciliation اور security audit نہ ہو۔

Security
--------
- APK میں MT5 password یا broker token hard-code نہیں کیا گیا۔
- Password app سے backend کو connect request میں بھیجا جاتا ہے؛ صرف trusted،
  encrypted VPN/TLS link پر استعمال کریں۔
- API key لازمی ہے، مگر اکیلی API key TLS کا متبادل نہیں۔
- Backend config.json اور logs کو محفوظ رکھیں۔ Public internet پر port 8787 نہ کھولیں۔
- Demo/Real کا خودکار detection MT5 account_info کے server/login سے best-effort ہے۔
  App Real account پر connect ہونے پر warning دکھاتا ہے، لیکن صارف کو خود verify
  کرنا ہوگا۔ Strategy start کا API endpoint real accounts کو default طور پر روکتا ہے؛
  config میں allow_real_trading=false ہے۔


Strategy File Import (اس ورژن میں)
----------------------------------
Android app میں IMPORT STRATEGY JSON FILE منتخب کریں۔ صرف JSON strategy profile قبول ہے؛
یہ عام .mq5/.ex5 EA یا arbitrary Python/JavaScript executable کو run نہیں کرتا۔
Import کرتے وقت موجودہ strategy OFF ہونی چاہیے۔ Import کے بعد Imported Strategy منتخب ہو
جاتی ہے؛ Built-in اور Imported ایک ساتھ نہیں چلتے۔ پھر RUN SELECTED STRATEGY بٹن ON/OFF
سے منتخب strategy کنٹرول کریں۔

نمونہ strategy-profile.json:
{
  "lots": [0.01, 0.02, 0.04, 0.06],
  "target_before_last": 1.0,
  "target_at_last": 3.0,
  "emergency_loss": -50.0,
  "poll_seconds": 5,
  "restart_delay_seconds": 2,
  "signal_rule": "price_direction"
}

Imported JSON اس وقت صرف اوپر دیے گئے risk/timing/lot settings اور price_direction signal
کو تبدیل کرتا ہے؛ یہ arbitrary custom code نہیں چلاتا۔ پہلے Demo account پر verify کریں۔
