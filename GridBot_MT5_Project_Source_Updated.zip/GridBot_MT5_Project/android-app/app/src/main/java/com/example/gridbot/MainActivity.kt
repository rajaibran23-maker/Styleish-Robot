package com.example.gridbot

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var backend: EditText
    private lateinit var apiKey: EditText
    private lateinit var login: EditText
    private lateinit var password: EditText
    private lateinit var server: EditText
    private lateinit var symbol: EditText
    private lateinit var status: TextView
    private lateinit var autoButton: Button
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private var auto = false
    private var selected = "builtin"
    private val PICK_STRATEGY = 701

    private val bg = Color.rgb(7, 13, 27)
    private val panel = Color.rgb(18, 29, 51)
    private val panel2 = Color.rgb(23, 38, 65)
    private val cyan = Color.rgb(30, 211, 235)
    private val green = Color.rgb(0, 220, 125)
    private val red = Color.rgb(255, 91, 105)
    private val muted = Color.rgb(155, 171, 194)
    private val white = Color.rgb(242, 247, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        scroll = ScrollView(this).apply { fillViewport = true }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(22))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomBar(), LinearLayout.LayoutParams(-1, dp(68)))
        setContentView(root)

        buildDashboard()
    }

    private fun buildDashboard() {
        content.removeAllViews()
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "G"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(bg); background = shape(cyan, 18); layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
        }
        brand.addView(logo)
        val brandText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        brandText.addView(label("GRIDBOT", 20f, white, true))
        brandText.addView(label("AUTOMATIC TRADING ROBOT", 10f, cyan, true))
        brand.addView(brandText, LinearLayout.LayoutParams(0, -2, 1f))
        brand.addView(pill("●  ROBOT: ${if (auto) "ON" else "OFF"}", if (auto) green else red))
        content.addView(brand)
        gap(22)
        content.addView(label("Home Dashboard", 29f, white, true))
        content.addView(label("Your trading control center", 13f, muted))
        gap(18)

        card {
            row {
                addView(iconTile("■", red))
                val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
                col.addView(label("ROBOT MASTER STATUS", 12f, muted, true))
                col.addView(label(if (auto) "RUNNING" else "STOPPED / STANDBY", 19f, if (auto) green else red, true))
                addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                addView(pill(if (auto) "ON" else "OFF", if (auto) green else red))
            }
            gap(16)
            row {
                addView(label("Active Lot Size: 0.01", 14f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
                addView(label("MT5 AUTO", 13f, cyan, true))
            }
            gap(15)
            row {
                autoButton = actionButton(if (auto) "STOP ROBOT" else "START ROBOT", if (auto) red else green)
                autoButton.isEnabled = false
                autoButton.setOnClickListener {
                    if (!auto) android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Start strategy?")
                        .setMessage("DEMO account recommended. Automated trading sends real MT5 orders if connected to a live account. Loss may exceed configured limits.")
                        .setNegativeButton("CANCEL", null)
                        .setPositiveButton("I UNDERSTAND") { _, _ -> setAuto(true) }.show()
                    else setAuto(false)
                }
                addView(autoButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(8) })
                val stop = actionButton("REFRESH", panel2)
                stop.setOnClickListener { refreshStatus() }
                addView(stop, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(8) })
            }
        }
        gap(14)

        sectionCard("⌁", "BROKER CONNECTION", "Connect your Exness MT5 account")
        card {
            backend = field("Secure backend URL (https://…)")
            addView(backend, fieldParams())
            apiKey = field("Backend API key", true)
            addView(apiKey, fieldParams())
            login = field("MT5 account number")
            addView(login, fieldParams())
            password = field("MT5 account password", true)
            addView(password, fieldParams())
            server = field("Broker server name (e.g. Exness-MT5Trial)")
            addView(server, fieldParams())
            symbol = field("Trading symbol").apply { setText("XAUUSDm") }
            addView(symbol, fieldParams())
            gap(10)
            val connect = actionButton("CONNECT MT5", cyan)
            connect.setTextColor(bg)
            connect.setOnClickListener {
                val body = JSONObject().put("login", login.text.toString().toLongOrNull() ?: 0)
                    .put("password", password.text.toString()).put("server", server.text.toString())
                    .put("symbol", symbol.text.toString())
                request("POST", "/connect", body) { r ->
                    status.text = "Connected: ${r.optString("login")}\nMode: ${r.optString("account_mode")}\nStrategy: $selected"
                    autoButton.isEnabled = true
                }
            }
            addView(connect, LinearLayout.LayoutParams(-1, dp(50)))
            gap(8)
            val disconnect = actionButton("DISCONNECT", panel2)
            disconnect.setOnClickListener {
                request("POST", "/disconnect", JSONObject()) {
                    auto = false
                    autoButton.text = "START ROBOT"
                    autoButton.isEnabled = false
                    status.text = "Disconnected"
                }
            }
            addView(disconnect, LinearLayout.LayoutParams(-1, dp(48)))
        }
        gap(14)

        sectionCard("▣", "VPS / SERVER", "Windows VPS with desktop MT5 terminal is required")
        card {
            addView(label("Backend status and trading information", 13f, muted))
            gap(10)
            status = label("Not connected\nLots: 0.01 → 0.02 → 0.04 → 0.06\nCheck interval: 5 seconds\nRestart delay: 2 seconds", 14f, white)
            addView(status)
            gap(12)
            val refresh = actionButton("REFRESH STATUS", panel2)
            refresh.setOnClickListener { refreshStatus() }
            addView(refresh, LinearLayout.LayoutParams(-1, dp(48)))
        }
        gap(14)

        sectionCard("↗", "STRATEGY CONTROL", "Choose one active strategy at a time")
        card {
            row {
                val built = actionButton("BUILT-IN", panel2)
                built.setOnClickListener { chooseStrategy("builtin") }
                addView(built, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
                val imported = actionButton("IMPORTED", panel2)
                imported.setOnClickListener { chooseStrategy("imported") }
                addView(imported, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
            }
            gap(9)
            val pick = actionButton("＋  IMPORT STRATEGY JSON", cyan)
            pick.setTextColor(bg)
            pick.setOnClickListener {
                if (auto) { toast("Turn strategy OFF before importing"); return@setOnClickListener }
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                }
                startActivityForResult(i, PICK_STRATEGY)
            }
            addView(pick, LinearLayout.LayoutParams(-1, dp(50)))
            gap(8)
            addView(label("Imported profiles accept JSON settings only. They do not run .mq5/.ex5 executable files. Imported strategy replaces the built-in strategy while selected.", 12f, muted))
        }
        gap(14)

        sectionCard("☷", "LOT & RISK SETTINGS", "Current strategy profile")
        card {
            addView(label("Lot sequence", 12f, muted, true))
            addView(label("0.01   →   0.02   →   0.04   →   0.06", 18f, cyan, true))
            gap(9)
            addView(label("Basket target: +$1 before 4th lot  •  +$3 with 4 positions", 13f, white))
            gap(7)
            addView(label("Emergency loss trigger: -$50 (not a guaranteed maximum loss)", 12f, red))
            gap(7)
            addView(label("Check every 5 seconds  •  Restart after close: 2 seconds", 12f, muted))
        }
        gap(14)

        sectionCard("▤", "LIVE STATUS", "Connection and basket information")
        card { addView(status) }
        gap(12)
        addView(label("SECURITY NOTE", 11f, cyan, true))
        addView(label("Use DEMO first. Keep API keys and MT5 passwords private. Do not expose the backend directly to the public internet.", 12f, muted))
        gap(12)
    }

    private fun refreshStatus() {
        request("GET", "/status", null) { r ->
            auto = r.optBoolean("auto_trading")
            selected = r.optString("selected_strategy", selected)
            autoButton.text = if (auto) "STOP ROBOT" else "START ROBOT"
            status.text = "Connected: ${r.optBoolean("connected")}\nMode: ${r.optString("account_mode")}\nSelected: $selected\nAuto: $auto\nPositions: ${r.optInt("positions")}\nBasket P/L: ${r.optDouble("basket_profit")}\nError: ${r.optString("last_error")}"
            buildDashboard()
        }
    }

    private fun sectionCard(icon: String, title: String, subtitle: String) {
        card {
            row {
                addView(label(icon, 25f, cyan, true))
                val c = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
                c.addView(label(title, 16f, white, true))
                c.addView(label(subtitle, 12f, muted))
                addView(c)
            }
        }
    }

    private fun bottomBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(7), dp(5), dp(7))
            background = shape(panel, 0, topOnly = true)
        }
        val items = listOf("⌂\nHome", "▤\nBroker", "▱\nVPS", "⏻\nRobot", "☷\nLots", "▱\nFiles")
        items.forEachIndexed { index, name ->
            val t = TextView(this).apply {
                text = name; gravity = Gravity.CENTER; textSize = 10f
                setTextColor(if (index == 0) cyan else muted)
                setTypeface(null, Typeface.BOLD)
                setPadding(dp(2), dp(5), dp(2), dp(5))
                setOnClickListener {
                    val target = when (index) { 1 -> 2; 2 -> 3; 3 -> 4; 4 -> 5; 5 -> 4; else -> 0 }
                    scroll.post { scroll.smoothScrollTo(0, content.getChildAt(target.coerceAtMost(content.childCount - 1)).top) }
                }
            }
            bar.addView(t, LinearLayout.LayoutParams(0, -1, 1f))
        }
        return bar
    }

    private fun card(block: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(17), dp(17), dp(17))
            background = shape(panel, 22, stroke = Color.rgb(42, 59, 91))
        }
        box.block()
        content.addView(box, LinearLayout.LayoutParams(-1, -2))
    }
    private fun LinearLayout.row(block: LinearLayout.() -> Unit) {
        val r = LinearLayout(this@MainActivity).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        r.block()
        addView(r, LinearLayout.LayoutParams(-1, -2))
    }
    private fun LinearLayout.gap(h: Int) { addView(View(this@MainActivity), LinearLayout.LayoutParams(1, dp(h))) }
    private fun gap(h: Int) { content.gap(h) }
    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setLineSpacing(dp(3).toFloat(), 1f)
    }
    private fun iconTile(s: String, color: Int) = TextView(this).apply {
        text = s; textSize = 24f; gravity = Gravity.CENTER; setTextColor(color)
        background = shape(panel2, 16); layoutParams = LinearLayout.LayoutParams(dp(55), dp(55))
    }
    private fun pill(s: String, color: Int) = TextView(this).apply {
        text = s; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; setTextColor(color)
        gravity = Gravity.CENTER; setPadding(dp(12), dp(9), dp(12), dp(9))
        background = shape(Color.rgb(38, 31, 52), 30, stroke = color)
    }
    private fun actionButton(s: String, color: Int) = Button(this).apply {
        text = s; textSize = 12f; isAllCaps = false; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (color == green || color == cyan) bg else white)
        background = shape(color, 15)
        stateListAnimator = null
    }
    private fun field(hintText: String, secret: Boolean = false): EditText {
        return EditText(this).apply {
            hint = hintText; textSize = 14f; setTextColor(white); setHintTextColor(muted)
            setPadding(dp(13), dp(9), dp(13), dp(9))
            background = shape(panel2, 12, stroke = Color.rgb(48, 67, 100))
            if (secret) inputType = 129
        }
    }
    private fun fieldParams() = LinearLayout.LayoutParams(-1, dp(51)).apply { bottomMargin = dp(9) }
    private fun shape(color: Int, radius: Int, stroke: Int? = null, topOnly: Boolean = false): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadii = if (topOnly) floatArrayOf(dp(16).toFloat(), dp(16).toFloat(), dp(16).toFloat(), dp(16).toFloat(), 0f, 0f, 0f, 0f)
                else FloatArray(8) { dp(radius).toFloat() }
            if (stroke != null) setStroke(dp(1), stroke)
        }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_STRATEGY && resultCode == RESULT_OK) data?.data?.let { uploadStrategy(it) }
    }
    private fun uploadStrategy(uri: Uri) {
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: run { toast("Cannot read file"); return }
        val base = backend.text.toString().trim().trimEnd('/')
        val key = apiKey.text.toString()
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "strategy.json"
        if (!base.startsWith("https://")) { toast("Use HTTPS backend URL"); return }
        executor.execute {
            try {
                val c = (URL(base + "/strategy/import").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 10000; readTimeout = 15000
                    setRequestProperty("X-API-Key", key)
                    setRequestProperty("X-Filename", if (name.endsWith(".json")) name else "strategy.json")
                    doOutput = true; setRequestProperty("Content-Type", "application/json")
                    outputStream.use { it.write(bytes) }
                }
                val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
                val txt = stream.bufferedReader().use { it.readText() }; c.disconnect()
                val r = JSONObject(txt)
                runOnUiThread {
                    if (r.has("detail")) toast(r.optString("detail"))
                    else { selected = "imported"; status.text = "Imported profile selected\nLots: ${r.optJSONArray("lots")}"; toast("Imported strategy JSON loaded") }
                }
            } catch (e: Exception) { runOnUiThread { toast("Import failed: ${e.message}") } }
        }
    }
    private fun chooseStrategy(mode: String) {
        request("POST", "/strategy/select", JSONObject().put("mode", mode)) {
            selected = mode; status.text = "Selected strategy: $mode\nRun button controls only this strategy."; toast("Selected: $mode")
        }
    }
    private fun setAuto(enabled: Boolean) {
        request("POST", "/auto", JSONObject().put("enabled", enabled)) {
            auto = enabled; autoButton.text = if (auto) "STOP ROBOT" else "START ROBOT"
        }
    }
    private fun request(method: String, path: String, body: JSONObject?, done: (JSONObject) -> Unit) {
        val base = backend.text.toString().trim().trimEnd('/')
        val key = apiKey.text.toString()
        if (!base.startsWith("https://")) { toast("Use HTTPS backend URL"); return }
        executor.execute {
            try {
                val c = (URL(base + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = method; connectTimeout = 10000; readTimeout = 15000
                    setRequestProperty("X-API-Key", key)
                    if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json"); outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) } }
                }
                val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
                val txt = stream.bufferedReader().use { it.readText() }; c.disconnect()
                val r = JSONObject(txt)
                runOnUiThread {
                    if (r.has("detail")) { status.text = "ERROR: ${r.optString("detail")}"; toast(r.optString("detail")) }
                    else done(r)
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Connection error: ${e.message}"; toast("Connection error: ${e.message}") }
            }
        }
    }
}
